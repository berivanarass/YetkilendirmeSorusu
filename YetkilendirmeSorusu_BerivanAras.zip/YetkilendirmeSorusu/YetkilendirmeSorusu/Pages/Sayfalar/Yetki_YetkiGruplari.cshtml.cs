using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace YetkilendirmeSorusu.Pages.Sayfalar
{
    public class Yetki_YetkiGruplariModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
