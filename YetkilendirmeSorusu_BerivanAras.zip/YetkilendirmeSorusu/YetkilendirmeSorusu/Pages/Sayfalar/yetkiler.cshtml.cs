using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace YetkilendirmeSorusu.Pages.Sayfalar
{
    public class kullaniciler : PageModel
    {
        public void OnGet()
        {
        }
    }
}
