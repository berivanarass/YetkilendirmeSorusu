using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace YetkilendirmeSorusu.Pages.Sayfalar
{
    public class Kullanici_YetkiGruplariModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
