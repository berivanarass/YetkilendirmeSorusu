using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace YetkilendirmeSorusu.Pages.Sayfalar
{
    public class YetkiGruplari_YetkiModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
