﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace YetkilendirmeSorusu.DBContext
{
    public class Yetkiler
    {
        [Key]
        public int ID { get; set; }
        [Column("YetkiIsimleri", TypeName = "Varchar(50)")]
        public string YetkiIsimleri { get; set; }
    }
}
