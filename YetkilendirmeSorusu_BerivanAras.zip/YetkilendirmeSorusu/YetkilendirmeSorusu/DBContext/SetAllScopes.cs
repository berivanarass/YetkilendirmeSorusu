﻿using YetkilendirmeSorusu.Operations;

namespace YetkilendirmeSorusu.DBContext
{
    public class SetAllScopes
    {
        WebApplicationBuilder builder;
        public SetAllScopes(WebApplicationBuilder Builder) 
        { 
            this.builder = Builder;
        }

        public void SetBuilders()
        {
            builder.Services.AddScoped<YetkilerController>();
            builder.Services.AddScoped<Yetki_YetkiGruplariController>();
            builder.Services.AddScoped<YetkiGruplariController>();
            builder.Services.AddScoped<YetkiGruplari_YetkiController>();
            builder.Services.AddScoped<YetkiGruplari_KullaniciController>();
            builder.Services.AddScoped<KullaniciController>();
            builder.Services.AddScoped<Kullanici_YetkiGruplariController>();
        }
    }
}
