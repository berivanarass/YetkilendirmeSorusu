﻿using Microsoft.EntityFrameworkCore;
using YetkilendirmeSorusu.DBContext;

public class YetkiDbContext : DbContext
{
    public YetkiDbContext(DbContextOptions<YetkiDbContext> options) : base(options)
    {
    }

    public DbSet<YetkiGruplari> YetkiGruplari { get; set; }
    public DbSet<Kullanicilar> Kullanicilar { get; set; }
    public DbSet<Yetkiler> Yetkiler { get; set; }
    public DbSet<Yetki_YetkiGruplari> Yetki_YetkiGruplari { get; set; }
    public DbSet<Kullanici_YetkGruplari> Kullanici_YetkGruplari { get; set; }
}
