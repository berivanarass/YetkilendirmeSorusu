﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace YetkilendirmeSorusu.DBContext
{
    public class Yetki_YetkiGruplari
    {
        [Key]
        public int ID { get; set; }
        [ForeignKey("Yetkiler")]
        public int yetkiId { get; set; }
        [ForeignKey("YetkiGruplari")]
        public int GrupId {  get; set; }

        public virtual Yetkiler Yetkiler { get; set; }
        public virtual YetkiGruplari YetkiGruplari { get; set; }

    }
}
