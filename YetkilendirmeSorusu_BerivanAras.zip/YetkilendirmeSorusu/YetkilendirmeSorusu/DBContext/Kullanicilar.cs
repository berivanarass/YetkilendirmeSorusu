﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace YetkilendirmeSorusu.DBContext
{
    public class Kullanicilar
    {
        [Key]
        public int ID { get; set; }
        [Column("KullaniciIsim", TypeName = "Varchar(100)")]
        public string KullaniciIsim { get; set; }

        [Column("KullaniciSoyisim", TypeName = "Varchar(100)")]
        public string KullaniciSoyisim { get; set; }
    }
}
