﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace YetkilendirmeSorusu.DBContext
{
    public class Kullanici_YetkGruplari
    {
        [Key]
        public int ID { get; set; }
        [ForeignKey("Kullanicilar")]
        public int KullaniciId { get; set; }
        [ForeignKey("YetkiGruplari")]
        public int GrupId { get; set; }

        public virtual Kullanicilar Kullanicilar{ get; set; }
        public virtual YetkiGruplari YetkiGruplari { get; set; }
    }
}
