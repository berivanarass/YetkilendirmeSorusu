﻿using Microsoft.AspNetCore.Mvc;
using YetkilendirmeSorusu.DBContext;

namespace YetkilendirmeSorusu.Operations
{
    [ApiController]
    [Route("api/[controller]")]
    public class KullaniciController
    {
        public YetkiDbContext _context;

        public KullaniciController(YetkiDbContext context)
        {
            _context = context;
        }
        private void SaveDatabase()
        {
            _context.SaveChanges();
        }
        [HttpGet("SatirlariGoster")]
        public List<Kullanicilar> SatirlariGoster()
        {
            var kullanicilar = _context.Kullanicilar.ToList();

            return kullanicilar;
        }

        [HttpGet("ReturnUserNameAndSurname")]
        public string ReturnUserNameAndSurname(int id)
        {
            var isim = _context.Kullanicilar.Where(yg => yg.ID == id)
                .Select(yg => yg.KullaniciIsim).ToList()[0];
            var soyisim = _context.Kullanicilar.Where(yg => yg.ID == id)
                .Select(yg => yg.KullaniciSoyisim).ToList()[0];

            return isim + ' ' + soyisim;
        }

        [HttpPost]
        [Route("EditUpdate")]
        public void EditUpdate(Kullanicilar newRow)
        {
            var kullaniciID = newRow.ID;
            var oldRow = _context.Kullanicilar.FirstOrDefault(e => e.ID == kullaniciID);


            _context.Entry(oldRow).CurrentValues.SetValues(newRow);
            SaveDatabase();
        }
    }
}
