﻿using Microsoft.AspNetCore.Mvc;
using YetkilendirmeSorusu.DBContext;

namespace YetkilendirmeSorusu.Operations
{
    [ApiController]
    [Route("api/[controller]")]
    public class YetkiGruplari_YetkiController : ControllerBase
    {
        public YetkiDbContext _context;

        public YetkiGruplari_YetkiController(YetkiDbContext context)
        {
            _context = context;
        }

        private void SaveDatabase()
        {
            _context.SaveChanges();
        }

        [HttpGet("FetchConnectedPermissions")]
        public List<int> FetchConnectedPermissions(int grupID)
        {
            var YetkiIDs = _context.Yetki_YetkiGruplari
                          .Where(yyg => yyg.GrupId == grupID)
                          .Select(yyg => yyg.yetkiId)
                          .Distinct()
                          .ToList();

            return YetkiIDs;
        }

        [HttpGet("FetchAllPermissions")]
        public List<int> FetchAllPermissions(int grupID, YetkilerController YetkilerController)
        {
            int YetkiCount = YetkilerController._context.Yetkiler.OrderByDescending(e => e.ID)
                .Select(e => e.ID).FirstOrDefault();
            var YetkiIDs = FetchConnectedPermissions(grupID);
            var otherYetkiIDs = Enumerable.Range(1, YetkiCount).Except(YetkiIDs).ToList();

            return otherYetkiIDs;
        }

        [HttpPost]
        [Route("AddNewData")]
        public void AddNewData(Yetki_YetkiGruplari generatedRow)
        {
            Yetki_YetkiGruplari newRow = new Yetki_YetkiGruplari { yetkiId = generatedRow.yetkiId, GrupId = generatedRow.GrupId };
            _context.Yetki_YetkiGruplari.Add(newRow);
            SaveDatabase();
        }

        [HttpPost]
        [Route("DeleteData")]
        public void DeleteData(Yetki_YetkiGruplari currentRow)
        {
            int ID = currentRow.ID;
            var deletedRow = _context.Yetki_YetkiGruplari.FirstOrDefault(e => e.ID == ID);

            _context.Yetki_YetkiGruplari.Remove(deletedRow);
            SaveDatabase();
        }
    }
}
