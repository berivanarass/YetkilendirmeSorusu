﻿using Microsoft.AspNetCore.Mvc;
using YetkilendirmeSorusu.DBContext;

namespace YetkilendirmeSorusu.Operations
{
    [ApiController]
    [Route("api/[controller]")]
    public class YetkiGruplariController : ControllerBase
    {
        public YetkiDbContext _context;

        public YetkiGruplariController(YetkiDbContext context)
        {
            _context = context;
        }

        private void SaveDatabase()
        {
            _context.SaveChanges();
        }

        [HttpGet("SatirlariGoster")]
        public List<YetkiGruplari> SatirlariGoster()
        {
            var yetkiGruplari = _context.YetkiGruplari.ToList();

            return yetkiGruplari;
        }

        [HttpGet("ReturnGroupName")]
        public string ReturnGroupName(int id)
        {
            return _context.YetkiGruplari.Where(yg => yg.ID == id)
                .Select(yg => yg.YetkiGrupIsimleri).ToList()[0];

        }

        [HttpPost]
        [Route("EditUpdateYetkiGruplari")]
        public void EditUpdateYetkiGruplari(YetkiGruplari newRow)
        {
            var yetkiIsim = newRow.YetkiGrupIsimleri;
            var yetkiID = newRow.ID;
            var oldRow = _context.YetkiGruplari.FirstOrDefault(e => e.ID == yetkiID);


            _context.Entry(oldRow).CurrentValues.SetValues(newRow);
            SaveDatabase();
        }
    }
}
