﻿using Microsoft.AspNetCore.Mvc;
using YetkilendirmeSorusu.DBContext;

namespace YetkilendirmeSorusu.Operations
{
    [ApiController]
    [Route("api/[controller]")]
    public class YetkiGruplari_KullaniciController : ControllerBase
    {
        public YetkiDbContext _context;

        public YetkiGruplari_KullaniciController(YetkiDbContext context)
        {
            _context = context;
        }

        private void SaveDatabase()
        {
            _context.SaveChanges();
        }

        [HttpGet("FetchConnectedUsers")]
        public List<int> FetchConnectedUsers(int grupID)
        {
            var kullaniciIDs = _context.Kullanici_YetkGruplari
                          .Where(yyg => yyg.GrupId == grupID)
                          .Select(yyg => yyg.KullaniciId)
                          .Distinct()
                          .ToList();

            return kullaniciIDs;
        }

        [HttpGet("FetchAllUsers")]
        public List<int> FetchAllUsers(int grupID, KullaniciController kullaniciController)
        {
            int kullaniciCount = kullaniciController._context.Kullanicilar.OrderByDescending(e => e.ID)
                .Select(e => e.ID).FirstOrDefault();
            var kullaniciIDs = FetchConnectedUsers(grupID);
            var otherKullaniciIDs = Enumerable.Range(1, kullaniciCount).Except(kullaniciIDs).ToList();

            return otherKullaniciIDs;
        }

        [HttpPost]
        [Route("AddNewData")]
        public void AddNewData(Kullanici_YetkGruplari generatedRow)
        {
            Kullanici_YetkGruplari newRow = new Kullanici_YetkGruplari { KullaniciId = generatedRow.KullaniciId, GrupId = generatedRow.GrupId };
            _context.Kullanici_YetkGruplari.Add(newRow);
            SaveDatabase();
        }

        [HttpPost]
        [Route("DeleteData")]
        public void DeleteData(Kullanici_YetkGruplari currentRow)
        {
            int ID = currentRow.ID;
            var deletedRow = _context.Kullanici_YetkGruplari.FirstOrDefault(e => e.ID == ID);

            _context.Kullanici_YetkGruplari.Remove(deletedRow);
            SaveDatabase();
        }
    }
}
