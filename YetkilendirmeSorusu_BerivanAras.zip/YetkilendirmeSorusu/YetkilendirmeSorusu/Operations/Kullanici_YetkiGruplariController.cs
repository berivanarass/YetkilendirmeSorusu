﻿using Microsoft.AspNetCore.Mvc;
using YetkilendirmeSorusu.DBContext;

namespace YetkilendirmeSorusu.Operations
{
    [ApiController]
    [Route("api/[controller]")]
    public class Kullanici_YetkiGruplariController
    {
        public YetkiDbContext _context;

        public Kullanici_YetkiGruplariController(YetkiDbContext context)
        {
            _context = context;
        }

        private void SaveDatabase()
        {
            _context.SaveChanges();
        }

        [HttpGet("FetchConnectedGroups")]
        public List<int> FetchConnectedGroups(int kullaniciId)
        {
            var grupIDs = _context.Kullanici_YetkGruplari
                          .Where(yyg => yyg.KullaniciId == kullaniciId)
                          .Select(yyg => yyg.GrupId)
                          .Distinct()
                          .ToList();

            return grupIDs;
        }

        [HttpGet("FetchAllGroups")]
        public List<int> FetchAllGroups(int kullaniciID, YetkiGruplariController yetkiGruplariController)
        {
            int grupCount = yetkiGruplariController._context.YetkiGruplari.OrderByDescending(e => e.ID)
                .Select(e => e.ID).FirstOrDefault();
            var grupIDs = FetchConnectedGroups(kullaniciID);
            var otherGrupIDs = Enumerable.Range(1, grupCount).Except(grupIDs).ToList();

            return otherGrupIDs;
        }

        [HttpPost]
        [Route("AddNewData")]
        public void AddNewData(Kullanici_YetkGruplari generatedRow)
        {
            Kullanici_YetkGruplari newRow = new Kullanici_YetkGruplari { KullaniciId = generatedRow.KullaniciId, GrupId = generatedRow.GrupId };
            _context.Kullanici_YetkGruplari.Add(newRow);
            SaveDatabase();
        }

        [HttpPost]
        [Route("DeleteData")]
        public void DeleteData(Kullanici_YetkGruplari currentRow)
        {
            int ID = currentRow.ID;
            var deletedRow = _context.Kullanici_YetkGruplari.FirstOrDefault(e => e.ID == ID);

            _context.Kullanici_YetkGruplari.Remove(deletedRow);
            SaveDatabase();
        }
    }
}
