﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using YetkilendirmeSorusu.DBContext;

namespace YetkilendirmeSorusu.Operations
{
    [ApiController]
    [Route("api/[controller]")]
    public class Yetki_YetkiGruplariController : ControllerBase
    {
        public YetkiDbContext _context;

        public Yetki_YetkiGruplariController(YetkiDbContext context)
        {
            _context = context;
        }

        private void SaveDatabase()
        {
            _context.SaveChanges();
        }

        [HttpGet("FetchConnectedGroups")]
        public List<int> FetchConnectedGroups(int yetkiID)
        {
            var grupIDs = _context.Yetki_YetkiGruplari
                          .Where(yyg => yyg.yetkiId == yetkiID)
                          .Select(yyg => yyg.GrupId)
                          .Distinct()
                          .ToList();

            return grupIDs;
        }

        [HttpGet("FetchAllGroups")]
        public List<int> FetchAllGroups(int yetkiID, YetkiGruplariController yetkiGruplariController)
        {
            int grupCount = yetkiGruplariController._context.YetkiGruplari.OrderByDescending(e => e.ID)
                .Select(e => e.ID).FirstOrDefault();
            var grupIDs = FetchConnectedGroups(yetkiID);
            var otherGrupIDs = Enumerable.Range(1, grupCount).Except(grupIDs).ToList();

            return otherGrupIDs;
        }

        [HttpPost]
        [Route("AddNewData")]
        public void AddNewData(Yetki_YetkiGruplari generatedRow)
        {
            Yetki_YetkiGruplari newRow = new Yetki_YetkiGruplari { yetkiId = generatedRow.yetkiId, GrupId = generatedRow.GrupId };
            _context.Yetki_YetkiGruplari.Add(newRow);
            SaveDatabase();
        }

        [HttpPost]
        [Route("DeleteData")]
        public void DeleteData(Yetki_YetkiGruplari currentRow)
        {
            int ID = currentRow.ID;
            var deletedRow = _context.Yetki_YetkiGruplari.FirstOrDefault(e => e.ID == ID);

            _context.Yetki_YetkiGruplari.Remove(deletedRow);
            SaveDatabase();
        }
    }
}
