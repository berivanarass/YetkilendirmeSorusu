﻿using Microsoft.AspNetCore.Mvc;
using YetkilendirmeSorusu.DBContext;

namespace YetkilendirmeSorusu.Operations
{
    [ApiController]
    [Route("api/[controller]")]
    public class YetkilerController : ControllerBase
    {
        public YetkiDbContext _context;

        public YetkilerController(YetkiDbContext context)
        {
            _context = context;
        }
        private void SaveDatabase()
        {
            _context.SaveChanges();
        }
        [HttpGet("SatirlariGoster")]
        public List<Yetkiler> SatirlariGoster()
        {
            var yetkiler = _context.Yetkiler.ToList();

            return yetkiler;
        }

        [HttpGet("ReturnPermissionName")]
        public string ReturnPermissionName(int id)
        {
            return _context.Yetkiler.Where(yg => yg.ID == id)
                .Select(yg => yg.YetkiIsimleri).ToList()[0];

        }

        [HttpPost]
        [Route("EditUpdate")]
        public void EditUpdate(Yetkiler newRow)
        {
            var yetkiIsim = newRow.YetkiIsimleri;
            var yetkiID = newRow.ID;
            var oldRow = _context.Yetkiler.FirstOrDefault(e => e.ID == yetkiID);


            _context.Entry(oldRow).CurrentValues.SetValues(newRow);
            SaveDatabase();
        }
    }
}
