﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace YetkilendirmeSorusu.Migrations
{
    /// <inheritdoc />
    public partial class AddNewRelations : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Kullanici_YetkGruplari",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    KullaniciId = table.Column<int>(type: "int", nullable: false),
                    GrupId = table.Column<int>(type: "int", nullable: false),
                    KullanicilarID = table.Column<int>(type: "int", nullable: false),
                    kullaniciGruplariID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Kullanici_YetkGruplari", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Kullanici_YetkGruplari_Kullanicilar_KullanicilarID",
                        column: x => x.KullanicilarID,
                        principalTable: "Kullanicilar",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Kullanici_YetkGruplari_kullaniciGruplari_kullaniciGruplariID",
                        column: x => x.kullaniciGruplariID,
                        principalTable: "kullaniciGruplari",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "kullanici_kullaniciGruplaris",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    kullaniciId = table.Column<int>(type: "int", nullable: false),
                    GrupId = table.Column<int>(type: "int", nullable: false),
                    kullanicilerID = table.Column<int>(type: "int", nullable: false),
                    kullaniciGruplariID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_kullanici_kullaniciGruplaris", x => x.ID);
                    table.ForeignKey(
                        name: "FK_kullanici_kullaniciGruplaris_kullaniciGruplari_kullaniciGruplariID",
                        column: x => x.kullaniciGruplariID,
                        principalTable: "kullaniciGruplari",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_kullanici_kullaniciGruplaris_kullaniciler_kullanicilerID",
                        column: x => x.kullanicilerID,
                        principalTable: "kullaniciler",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Kullanici_YetkGruplari_KullanicilarID",
                table: "Kullanici_YetkGruplari",
                column: "KullanicilarID");

            migrationBuilder.CreateIndex(
                name: "IX_Kullanici_YetkGruplari_kullaniciGruplariID",
                table: "Kullanici_YetkGruplari",
                column: "kullaniciGruplariID");

            migrationBuilder.CreateIndex(
                name: "IX_kullanici_kullaniciGruplaris_kullaniciGruplariID",
                table: "kullanici_kullaniciGruplaris",
                column: "kullaniciGruplariID");

            migrationBuilder.CreateIndex(
                name: "IX_kullanici_kullaniciGruplaris_kullanicilerID",
                table: "kullanici_kullaniciGruplaris",
                column: "kullanicilerID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Kullanici_YetkGruplari");

            migrationBuilder.DropTable(
                name: "kullanici_kullaniciGruplaris");
        }
    }
}
