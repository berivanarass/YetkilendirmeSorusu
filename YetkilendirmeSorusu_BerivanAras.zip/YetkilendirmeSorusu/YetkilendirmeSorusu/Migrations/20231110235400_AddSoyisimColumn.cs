﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace YetkilendirmeSorusu.Migrations
{
    /// <inheritdoc />
    public partial class AddSoyisimColumn : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "KullaniciIsimleri",
                table: "Kullanicilar",
                newName: "KullaniciSoyisim");

            migrationBuilder.AddColumn<string>(
                name: "KullaniciIsim",
                table: "Kullanicilar",
                type: "Varchar(100)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "KullaniciIsim",
                table: "Kullanicilar");

            migrationBuilder.RenameColumn(
                name: "KullaniciSoyisim",
                table: "Kullanicilar",
                newName: "KullaniciIsimleri");
        }
    }
}
