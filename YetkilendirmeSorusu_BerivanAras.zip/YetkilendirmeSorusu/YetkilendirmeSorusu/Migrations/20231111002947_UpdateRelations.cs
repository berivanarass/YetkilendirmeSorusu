﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace YetkilendirmeSorusu.Migrations
{
    /// <inheritdoc />
    public partial class UpdateRelations : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Kullanici_YetkGruplari_Kullanicilar_KullanicilarID",
                table: "Kullanici_YetkGruplari");

            migrationBuilder.DropForeignKey(
                name: "FK_Kullanici_YetkGruplari_kullaniciGruplari_kullaniciGruplariID",
                table: "Kullanici_YetkGruplari");

            migrationBuilder.DropForeignKey(
                name: "FK_kullanici_kullaniciGruplaris_kullaniciGruplari_kullaniciGruplariID",
                table: "kullanici_kullaniciGruplaris");

            migrationBuilder.DropForeignKey(
                name: "FK_kullanici_kullaniciGruplaris_kullaniciler_kullanicilerID",
                table: "kullanici_kullaniciGruplaris");

            migrationBuilder.DropIndex(
                name: "IX_kullanici_kullaniciGruplaris_kullaniciGruplariID",
                table: "kullanici_kullaniciGruplaris");

            migrationBuilder.DropIndex(
                name: "IX_kullanici_kullaniciGruplaris_kullanicilerID",
                table: "kullanici_kullaniciGruplaris");

            migrationBuilder.DropIndex(
                name: "IX_Kullanici_YetkGruplari_KullanicilarID",
                table: "Kullanici_YetkGruplari");

            migrationBuilder.DropIndex(
                name: "IX_Kullanici_YetkGruplari_kullaniciGruplariID",
                table: "Kullanici_YetkGruplari");

            migrationBuilder.DropColumn(
                name: "kullaniciGruplariID",
                table: "kullanici_kullaniciGruplaris");

            migrationBuilder.DropColumn(
                name: "kullanicilerID",
                table: "kullanici_kullaniciGruplaris");

            migrationBuilder.DropColumn(
                name: "KullanicilarID",
                table: "Kullanici_YetkGruplari");

            migrationBuilder.DropColumn(
                name: "kullaniciGruplariID",
                table: "Kullanici_YetkGruplari");

            migrationBuilder.CreateIndex(
                name: "IX_kullanici_kullaniciGruplaris_GrupId",
                table: "kullanici_kullaniciGruplaris",
                column: "GrupId");

            migrationBuilder.CreateIndex(
                name: "IX_kullanici_kullaniciGruplaris_kullaniciId",
                table: "kullanici_kullaniciGruplaris",
                column: "kullaniciId");

            migrationBuilder.CreateIndex(
                name: "IX_Kullanici_YetkGruplari_GrupId",
                table: "Kullanici_YetkGruplari",
                column: "GrupId");

            migrationBuilder.CreateIndex(
                name: "IX_Kullanici_YetkGruplari_KullaniciId",
                table: "Kullanici_YetkGruplari",
                column: "KullaniciId");

            migrationBuilder.AddForeignKey(
                name: "FK_Kullanici_YetkGruplari_Kullanicilar_KullaniciId",
                table: "Kullanici_YetkGruplari",
                column: "KullaniciId",
                principalTable: "Kullanicilar",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Kullanici_YetkGruplari_kullaniciGruplari_GrupId",
                table: "Kullanici_YetkGruplari",
                column: "GrupId",
                principalTable: "kullaniciGruplari",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_kullanici_kullaniciGruplaris_kullaniciGruplari_GrupId",
                table: "kullanici_kullaniciGruplaris",
                column: "GrupId",
                principalTable: "kullaniciGruplari",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_kullanici_kullaniciGruplaris_kullaniciler_kullaniciId",
                table: "kullanici_kullaniciGruplaris",
                column: "kullaniciId",
                principalTable: "kullaniciler",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Kullanici_YetkGruplari_Kullanicilar_KullaniciId",
                table: "Kullanici_YetkGruplari");

            migrationBuilder.DropForeignKey(
                name: "FK_Kullanici_YetkGruplari_kullaniciGruplari_GrupId",
                table: "Kullanici_YetkGruplari");

            migrationBuilder.DropForeignKey(
                name: "FK_kullanici_kullaniciGruplaris_kullaniciGruplari_GrupId",
                table: "kullanici_kullaniciGruplaris");

            migrationBuilder.DropForeignKey(
                name: "FK_kullanici_kullaniciGruplaris_kullaniciler_kullaniciId",
                table: "kullanici_kullaniciGruplaris");

            migrationBuilder.DropIndex(
                name: "IX_kullanici_kullaniciGruplaris_GrupId",
                table: "kullanici_kullaniciGruplaris");

            migrationBuilder.DropIndex(
                name: "IX_kullanici_kullaniciGruplaris_kullaniciId",
                table: "kullanici_kullaniciGruplaris");

            migrationBuilder.DropIndex(
                name: "IX_Kullanici_YetkGruplari_GrupId",
                table: "Kullanici_YetkGruplari");

            migrationBuilder.DropIndex(
                name: "IX_Kullanici_YetkGruplari_KullaniciId",
                table: "Kullanici_YetkGruplari");

            migrationBuilder.AddColumn<int>(
                name: "kullaniciGruplariID",
                table: "kullanici_kullaniciGruplaris",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "kullanicilerID",
                table: "kullanici_kullaniciGruplaris",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "KullanicilarID",
                table: "Kullanici_YetkGruplari",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "kullaniciGruplariID",
                table: "Kullanici_YetkGruplari",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_kullanici_kullaniciGruplaris_kullaniciGruplariID",
                table: "kullanici_kullaniciGruplaris",
                column: "kullaniciGruplariID");

            migrationBuilder.CreateIndex(
                name: "IX_kullanici_kullaniciGruplaris_kullanicilerID",
                table: "kullanici_kullaniciGruplaris",
                column: "kullanicilerID");

            migrationBuilder.CreateIndex(
                name: "IX_Kullanici_YetkGruplari_KullanicilarID",
                table: "Kullanici_YetkGruplari",
                column: "KullanicilarID");

            migrationBuilder.CreateIndex(
                name: "IX_Kullanici_YetkGruplari_kullaniciGruplariID",
                table: "Kullanici_YetkGruplari",
                column: "kullaniciGruplariID");

            migrationBuilder.AddForeignKey(
                name: "FK_Kullanici_YetkGruplari_Kullanicilar_KullanicilarID",
                table: "Kullanici_YetkGruplari",
                column: "KullanicilarID",
                principalTable: "Kullanicilar",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Kullanici_YetkGruplari_kullaniciGruplari_kullaniciGruplariID",
                table: "Kullanici_YetkGruplari",
                column: "kullaniciGruplariID",
                principalTable: "kullaniciGruplari",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_kullanici_kullaniciGruplaris_kullaniciGruplari_kullaniciGruplariID",
                table: "kullanici_kullaniciGruplaris",
                column: "kullaniciGruplariID",
                principalTable: "kullaniciGruplari",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_kullanici_kullaniciGruplaris_kullaniciler_kullanicilerID",
                table: "kullanici_kullaniciGruplaris",
                column: "kullanicilerID",
                principalTable: "kullaniciler",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
