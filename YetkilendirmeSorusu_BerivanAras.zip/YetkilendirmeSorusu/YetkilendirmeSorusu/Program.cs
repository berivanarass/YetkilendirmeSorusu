using Microsoft.EntityFrameworkCore;
using YetkilendirmeSorusu.DBContext;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();

var provider = builder.Services.BuildServiceProvider();
var configuration = provider.GetRequiredService<IConfiguration>();

builder.Services.AddDbContext<YetkiDbContext>(item => item.UseSqlServer(configuration.GetConnectionString("myconn")));
SetAllScopes scopes = new SetAllScopes(builder);
scopes.SetBuilders();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapRazorPages();

app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers(); // Ensure controllers are routed
    endpoints.MapRazorPages();
});

app.Run();
